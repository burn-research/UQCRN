/Users/imacremote/Distributions/NetSmoke_Linux-Master/SeReNetSMOKEpp-master/projects/Linux/SeReNetSMOKEpp.sh --input input.dic
