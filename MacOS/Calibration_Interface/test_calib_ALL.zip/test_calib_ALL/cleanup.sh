rm -r Workdir*
rm params.in*
rm LHS_*
rm results.*
rm PCE_*
rm dakota*.out
rm dakota.rst
rm dakota_tabular.dat
